# AED_Project_Fall_22
Group project collaborated with Akshita Pathania and Sri Vaishnavi Reddy

ONLINE RESIDENTIAL COMPLAINTS PORTAL

FINAL PROJECT DOCUMENT



TEAM 21 

SRI VAISHNAVI AEKKATI (NUID - 002760439)
ANAMIKA BHARALI ( NUID - 002776402)
AKSHITA PATHANIA ( NUID - 002728833 )



CONTENTS :

1.Project Statement
2.Approach



PROBLEM STATEMENT:

1. The traditional method of giving complaints or suggestions in any organization through a complaint or suggestion box is not accessible to everyone and it also doesn’t maintain records of the complaints received and neither do we get to know what the request status is.
2. This proposed project aims to develop an interactive and user-friendly online Complaints/Suggestions Portal for a Residential Housing Enterprise.

3. This helps all enterprises involved see the progress of the request raised.

Approach :

1. The motive of this project is to provide an online platform for the people of to put forward their complaints or suggestions regarding their issues.

2. The application requires the user to log in with his/her username to lodge a complaint or give a suggestion. The application holds different departments. Based on its type, the issue is forwarded to the concerned department. Further, the concerned department officials can view the issue and update its status. The user can also view the status of his complaint/suggestion. It also has an emergency request where they can send their location to the police department in emergency situations.

3. Through this application, the path to lodge a complaint or to give a suggestion becomes easier. With this, the issues can be addressed and processed effectively and relatively faster.

Our project also implements a few advanced features such as email verification on signing up and emails being sent with attachments
